import { pgTable, serial, text, integer, timestamp } from 'drizzle-orm/pg-core';

// CASINOS
export const casinos = pgTable("casinos", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rating: integer("rating").default(0),
  bonus: text("bonus"),
  url: text("url").notNull(),
});

// BONUSES
export const bonuses = pgTable("bonuses", {
  id: serial("id").primaryKey(),
  casinoId: integer("casino_id").notNull(),
  type: text("type").notNull(),
  amount: text("amount"),
  description: text("description"),
});

// USERS
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// REVIEWS
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  casinoId: integer("casino_id").notNull(),
  userId: integer("user_id").notNull(),
  rating: integer("rating").notNull(),
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow(),
});
