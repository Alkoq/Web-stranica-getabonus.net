
// server.ts — GetABonus Bonuses API (Express + Drizzle + PostgreSQL)
// ------------------------------------------------------------------
// Features:
// - Casinos & Bonuses tables (CREATE TABLE IF NOT EXISTS on startup — no external migration step required)
// - CRUD routes for /bonuses (+ filtering, sorting, pagination)
// - GET /bonuses/:id
// - POST /bonuses, PUT /bonuses/:id, DELETE /bonuses/:id
// - CSV export at GET /export/bonuses.csv
// - Optional JWT auth middleware (enable with REQUIRE_AUTH=true and set JWT_SECRET)
// - CORS, Helmet, JSON body limit, basic logging, structured error handler
// - Zod validation for payloads
//
// Quick start:
// 1) Save this file as server.ts
// 2) npm i express cors helmet morgan zod jsonwebtoken pg drizzle-orm
//    npm i -D typescript tsx @types/express @types/cors @types/morgan @types/jsonwebtoken
// 3) Create .env with: DATABASE_URL=postgres://user:pass@host:5432/db
//    (Optional) PORT=3001, REQUIRE_AUTH=true, JWT_SECRET=supersecret
// 4) Run: npx tsx server.ts
//
// Notes:
// - If you already have Drizzle schema files, you can ignore the inline SQL schema bootstrap below.
// - Table names used: casinos, bonuses
// - Currency default is 'USDT'; status in ('draft','published','expired'); type in ('deposit','no_deposit','cashback','freespins')
//
// ------------------------------------------------------------------

import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { z } from 'zod';
import jwt from 'jsonwebtoken';
import { Client } from 'pg';

// ---------- Environment ----------
const PORT = Number(process.env.PORT || 3001);
const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error('Missing DATABASE_URL in env.');
  process.exit(1);
}

const REQUIRE_AUTH = String(process.env.REQUIRE_AUTH || 'false').toLowerCase() === 'true';
const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production';

// ---------- PG Client ----------
const pgClient = new Client({
  connectionString: DATABASE_URL,
});
async function initDb() {
  await pgClient.connect();
  // Create tables if not exist (idempotent). Keep it simple & compatible.
  // CASINOS
  await pgClient.query(`
    CREATE TABLE IF NOT EXISTS casinos (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      slug TEXT NOT NULL UNIQUE,
      website TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `);
  // BONUSES
  await pgClient.query(`
    CREATE TABLE IF NOT EXISTS bonuses (
      id SERIAL PRIMARY KEY,
      casino_id INTEGER NOT NULL REFERENCES casinos(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      description TEXT,
      type TEXT NOT NULL CHECK (type IN ('deposit','no_deposit','cashback','freespins')),
      amount NUMERIC(18,2),
      currency TEXT NOT NULL DEFAULT 'USDT',
      min_deposit NUMERIC(18,2),
      wagering_requirement TEXT,
      promo_code TEXT,
      status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','expired')),
      start_date TIMESTAMP WITH TIME ZONE,
      end_date TIMESTAMP WITH TIME ZONE,
      terms_url TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `);
  // Indexes to speed up filters
  await pgClient.query(`CREATE INDEX IF NOT EXISTS idx_bonuses_casino_id ON bonuses(casino_id);`);
  await pgClient.query(`CREATE INDEX IF NOT EXISTS idx_bonuses_status ON bonuses(status);`);
  await pgClient.query(`CREATE INDEX IF NOT EXISTS idx_bonuses_type ON bonuses(type);`);
  await pgClient.query(`CREATE INDEX IF NOT EXISTS idx_bonuses_created_at ON bonuses(created_at);`);
  console.log('DB ready.');
}

// ---------- Minimal Drizzle-ish helpers (raw SQL) ----------
// We can use raw SQL with pg here to keep this single-file self-contained.
type BonusRow = {
  id: number;
  casino_id: number;
  title: string;
  description: string | null;
  type: 'deposit' | 'no_deposit' | 'cashback' | 'freespins';
  amount: string | null;
  currency: string;
  min_deposit: string | null;
  wagering_requirement: string | null;
  promo_code: string | null;
  status: 'draft' | 'published' | 'expired';
  start_date: string | null;
  end_date: string | null;
  terms_url: string | null;
  created_at: string;
  updated_at: string;
  casino_name?: string;
  casino_slug?: string;
};

// ---------- Validation ----------
const BonusCreateSchema = z.object({
  casino_id: z.number().int().positive().optional(),
  casino_slug: z.string().min(1).optional(), // alternatively specify by slug
  title: z.string().min(2),
  description: z.string().max(5000).optional().nullable(),
  type: z.enum(['deposit', 'no_deposit', 'cashback', 'freespins']),
  amount: z.coerce.number().nonnegative().optional().nullable(),
  currency: z.string().min(1).default('USDT'),
  min_deposit: z.coerce.number().nonnegative().optional().nullable(),
  wagering_requirement: z.string().max(1000).optional().nullable(),
  promo_code: z.string().max(200).optional().nullable(),
  status: z.enum(['draft', 'published', 'expired']).default('draft'),
  start_date: z.coerce.date().optional().nullable(),
  end_date: z.coerce.date().optional().nullable(),
  terms_url: z.string().url().optional().nullable(),
});

const BonusUpdateSchema = BonusCreateSchema.partial();

// ---------- Auth Middleware (Optional) ----------
function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!REQUIRE_AUTH) return next(); // disabled
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    jwt.verify(token, JWT_SECRET);
    return next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// ---------- Express App ----------
const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

// Health check
app.get('/health', async (_req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// Utility: resolve casino_id from slug (if provided)
async function resolveCasinoId(params: { casino_id?: number; casino_slug?: string }) {
  if (params.casino_id) return params.casino_id;
  if (!params.casino_slug) return undefined;
  const { rows } = await pgClient.query('SELECT id FROM casinos WHERE slug = $1', [params.casino_slug]);
  return rows[0]?.id;
}

// ---------- Bonuses: List with filters ----------
app.get('/bonuses', async (req, res, next) => {
  try {
    const {
      page = '1',
      pageSize = '10',
      sort = 'created_at.desc',
      casino_id,
      casino_slug,
      type,
      status,
      currency,
      q,
      min_amount,
      max_amount,
    } = req.query as Record<string, string>;

    const pageNum = Math.max(1, parseInt(String(page), 10) || 1);
    const sizeNum = Math.min(100, Math.max(1, parseInt(String(pageSize), 10) || 10));

    const where: string[] = [];
    const params: any[] = [];
    let joinCasino = false;

    // Filter by casino via id or slug
    if (casino_id) {
      where.push(`b.casino_id = $${params.length + 1}`);
      params.push(Number(casino_id));
    } else if (casino_slug) {
      joinCasino = true;
      where.push(`c.slug = $${params.length + 1}`);
      params.push(casino_slug);
    }

    if (type) {
      where.push(`b.type = $${params.length + 1}`);
      params.push(type);
    }
    if (status) {
      where.push(`b.status = $${params.length + 1}`);
      params.push(status);
    }
    if (currency) {
      where.push(`b.currency = $${params.length + 1}`);
      params.push(currency);
    }
    if (q) {
      where.push(`(b.title ILIKE $${params.length + 1} OR COALESCE(b.description,'') ILIKE $${params.length + 1})`);
      params.push(`%${q}%`);
    }
    if (min_amount) {
      where.push(`b.amount >= $${params.length + 1}`);
      params.push(Number(min_amount));
    }
    if (max_amount) {
      where.push(`b.amount <= $${params.length + 1}`);
      params.push(Number(max_amount));
    }

    const [sortCol, sortDirRaw] = String(sort).split('.');
    const validSortCols = new Set(['created_at', 'amount', 'title', 'start_date', 'end_date']);
    const sortColumn = validSortCols.has(sortCol) ? sortCol : 'created_at';
    const sortDir = sortDirRaw?.toLowerCase() === 'asc' ? 'ASC' : 'DESC';

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

    const baseFrom = joinCasino
      ? `FROM bonuses b JOIN casinos c ON c.id = b.casino_id`
      : `FROM bonuses b LEFT JOIN casinos c ON c.id = b.casino_id`;

    // Count total
    const countSql = `SELECT COUNT(*) AS total ${baseFrom} ${whereSql}`;
    const countRes = await pgClient.query(countSql, params);
    const total = Number(countRes.rows[0]?.total || 0);

    // Data page
    const offset = (pageNum - 1) * sizeNum;
    const dataSql = `
      SELECT 
        b.*,
        c.name AS casino_name,
        c.slug AS casino_slug
      ${baseFrom}
      ${whereSql}
      ORDER BY ${'b.' + sortColumn} ${sortDir}
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}
    `;
    const dataParams = [...params, sizeNum, offset];
    const dataRes = await pgClient.query<BonusRow>(dataSql, dataParams);

    res.json({
      page: pageNum,
      pageSize: sizeNum,
      total,
      totalPages: Math.ceil(total / sizeNum),
      items: dataRes.rows,
    });
  } catch (err) {
    next(err);
  }
});

// ---------- Bonuses: Get by ID ----------
app.get('/bonuses/:id', async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const { rows } = await pgClient.query<BonusRow>(`
      SELECT b.*, c.name AS casino_name, c.slug AS casino_slug
      FROM bonuses b
      LEFT JOIN casinos c ON c.id = b.casino_id
      WHERE b.id = $1
    `, [id]);
    const row = rows[0];
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  } catch (err) {
    next(err);
  }
});

// ---------- Bonuses: Create ----------
app.post('/bonuses', requireAdmin, async (req, res, next) => {
  try {
    const parsed = BonusCreateSchema.parse(req.body);
    const casinoId = await resolveCasinoId({ casino_id: parsed.casino_id, casino_slug: parsed.casino_slug });
    if (!casinoId) return res.status(400).json({ error: 'casino_id or casino_slug must reference an existing casino' });

    const now = new Date();
    const { rows } = await pgClient.query<BonusRow>(`
      INSERT INTO bonuses
        (casino_id, title, description, type, amount, currency, min_deposit, wagering_requirement, promo_code, status, start_date, end_date, terms_url, created_at, updated_at)
      VALUES
        ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
      RETURNING *;
    `, [
      casinoId,
      parsed.title,
      parsed.description ?? null,
      parsed.type,
      parsed.amount ?? null,
      parsed.currency ?? 'USDT',
      parsed.min_deposit ?? null,
      parsed.wagering_requirement ?? null,
      parsed.promo_code ?? null,
      parsed.status ?? 'draft',
      parsed.start_date ? new Date(parsed.start_date) : null,
      parsed.end_date ? new Date(parsed.end_date) : null,
      parsed.terms_url ?? null,
      now,
      now
    ]);
    res.status(201).json(rows[0]);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: err.errors });
    }
    next(err);
  }
});

// ---------- Bonuses: Update ----------
app.put('/bonuses/:id', requireAdmin, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const parsed = BonusUpdateSchema.parse(req.body);

    let casinoId: number | undefined = undefined;
    if (parsed.casino_id || parsed.casino_slug) {
      const resolved = await resolveCasinoId({ casino_id: parsed.casino_id, casino_slug: parsed.casino_slug });
      if (!resolved) return res.status(400).json({ error: 'casino_id or casino_slug must reference an existing casino' });
      casinoId = resolved;
    }

    // Build dynamic update
    const sets: string[] = [];
    const params: any[] = [];
    function addSet(col: string, val: any) {
      sets.push(`${col} = $${params.length + 1}`);
      params.push(val);
    }
    if (casinoId !== undefined) addSet('casino_id', casinoId);
    if (parsed.title !== undefined) addSet('title', parsed.title);
    if (parsed.description !== undefined) addSet('description', parsed.description);
    if (parsed.type !== undefined) addSet('type', parsed.type);
    if (parsed.amount !== undefined) addSet('amount', parsed.amount);
    if (parsed.currency !== undefined) addSet('currency', parsed.currency);
    if (parsed.min_deposit !== undefined) addSet('min_deposit', parsed.min_deposit);
    if (parsed.wagering_requirement !== undefined) addSet('wagering_requirement', parsed.wagering_requirement);
    if (parsed.promo_code !== undefined) addSet('promo_code', parsed.promo_code);
    if (parsed.status !== undefined) addSet('status', parsed.status);
    if (parsed.start_date !== undefined) addSet('start_date', parsed.start_date ? new Date(parsed.start_date) : null);
    if (parsed.end_date !== undefined) addSet('end_date', parsed.end_date ? new Date(parsed.end_date) : null);
    if (parsed.terms_url !== undefined) addSet('terms_url', parsed.terms_url);
    addSet('updated_at', new Date());

    if (!sets.length) return res.status(400).json({ error: 'No fields to update' });

    const sql = `UPDATE bonuses SET ${sets.join(', ')} WHERE id = $${params.length + 1} RETURNING *;`;
    const { rows } = await pgClient.query<BonusRow>(sql, [...params, id]);
    const row = rows[0];
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: err.errors });
    }
    next(err);
  }
});

// ---------- Bonuses: Delete ----------
app.delete('/bonuses/:id', requireAdmin, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const { rowCount } = await pgClient.query('DELETE FROM bonuses WHERE id = $1', [id]);
    if (!rowCount) return res.status(404).json({ error: 'Not found' });
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

// ---------- CSV Export ----------
function toCsv(rows: any[]) {
  if (!rows.length) return 'id,casino_id,casino_name,casino_slug,title,description,type,amount,currency,min_deposit,wagering_requirement,promo_code,status,start_date,end_date,terms_url,created_at,updated_at\n';
  const headers = [
    'id','casino_id','casino_name','casino_slug','title','description','type','amount','currency',
    'min_deposit','wagering_requirement','promo_code','status','start_date','end_date','terms_url','created_at','updated_at'
  ];
  const escape = (val: any) => {
    if (val === null || val === undefined) return '';
    const s = String(val).replace(/"/g, '""');
    if (s.search(/[",\n]/) >= 0) return `"${s}"`;
    return s;
  };
  const lines = [headers.join(',')];
  for (const r of rows) {
    const line = headers.map(h => escape(r[h])).join(',');
    lines.push(line);
  }
  return lines.join('\n') + '\n';
}

app.get('/export/bonuses.csv', async (req, res, next) => {
  try {
    const { rows } = await pgClient.query(`
      SELECT b.*, c.name AS casino_name, c.slug AS casino_slug
      FROM bonuses b
      LEFT JOIN casinos c ON c.id = b.casino_id
      ORDER BY b.created_at DESC
    `);
    const csv = toCsv(rows);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="bonuses.csv"');
    res.send(csv);
  } catch (err) {
    next(err);
  }
});

// ---------- Dev Seed (Only in development) ----------
app.post('/dev/seed', requireAdmin, async (req, res, next) => {
  try {
    if (process.env.NODE_ENV === 'production') {
      return res.status(403).json({ error: 'Seeding disabled in production' });
    }
    // Upsert a few casinos
    const casinos = [
      { name: 'Stake', slug: 'stake', website: 'https://stake.com' },
      { name: 'Roobet', slug: 'roobet', website: 'https://roobet.com' },
      { name: 'BC.Game', slug: 'bcgame', website: 'https://bc.game' },
      { name: 'Vave', slug: 'vave', website: 'https://vave.com' },
      { name: 'Rollbit', slug: 'rollbit', website: 'https://rollbit.com' },
    ];
    for (const c of casinos) {
      await pgClient.query(
        `INSERT INTO casinos (name, slug, website)
         VALUES ($1,$2,$3)
         ON CONFLICT (name) DO UPDATE SET website = EXCLUDED.website, updated_at = NOW()`,
        [c.name, c.slug, c.website]
      );
    }
    // Seed a couple of bonuses if none exist
    const existing = await pgClient.query('SELECT COUNT(*)::int AS n FROM bonuses');
    if (Number(existing.rows[0].n) === 0) {
      const { rows: stakeRow } = await pgClient.query('SELECT id FROM casinos WHERE slug=$1', ['stake']);
      const stakeId = stakeRow[0]?.id;
      if (stakeId) {
        await pgClient.query(`
          INSERT INTO bonuses
            (casino_id, title, description, type, amount, currency, min_deposit, wagering_requirement, promo_code, status, start_date, end_date, terms_url)
          VALUES
            ($1, '100% Deposit Bonus up to 500', 'Welcome package', 'deposit', 500, 'USDT', 20, '35x wagering', 'ALKOX', 'published', NOW(), NOW() + INTERVAL '30 days', 'https://stake.com/promotions')
        `, [stakeId]);
      }
    }
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

// ---------- Error Handler ----------
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error(err);
  res.status(500).json({ error: 'Internal Server Error' });
});

// ---------- Start ----------
initDb().then(() => {
  app.listen(PORT, () => {
    console.log(`Bonuses API running on http://localhost:${PORT}`);
  });
}).catch((e) => {
  console.error('Failed to init DB', e);
  process.exit(1);
});
