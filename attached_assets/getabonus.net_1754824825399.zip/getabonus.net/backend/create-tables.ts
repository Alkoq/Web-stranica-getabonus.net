import { db } from "./db/client";
import { casinos, bonuses, users, reviews } from "./db/schema";

async function createTables() {
  try {
    await db.execute(`
      CREATE TABLE IF NOT EXISTS casinos (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        rating INTEGER DEFAULT 0,
        bonus TEXT,
        url TEXT NOT NULL
      );
    `);

    await db.execute(`
      CREATE TABLE IF NOT EXISTS bonuses (
        id SERIAL PRIMARY KEY,
        casino_id INTEGER NOT NULL,
        type TEXT NOT NULL,
        amount TEXT,
        description TEXT
      );
    `);

    await db.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);

    await db.execute(`
      CREATE TABLE IF NOT EXISTS reviews (
        id SERIAL PRIMARY KEY,
        casino_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        rating INTEGER NOT NULL,
        comment TEXT,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);

    console.log("✅ Sve tabele su spremne!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Greška pri kreiranju tabela:", error);
    process.exit(1);
  }
}

createTables();