
-- ADMIN TABELA
CREATE TABLE IF NOT EXISTS admins (
  id VARCHAR(36) PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- CASINO TABELA
CREATE TABLE IF NOT EXISTS casinos (
  id VARCHAR(36) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  logo_url TEXT,
  website_url TEXT NOT NULL,
  affiliate_url TEXT,
  safety_index DECIMAL(3,1) NOT NULL,
  user_rating DECIMAL(3,1) DEFAULT 0,
  total_reviews INT DEFAULT 0,
  established_year INT,
  license VARCHAR(255),
  payment_methods TEXT,
  supported_currencies TEXT,
  game_providers TEXT,
  features TEXT,
  is_featured BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- BONUS TABELA
CREATE TABLE IF NOT EXISTS bonuses (
  id VARCHAR(36) PRIMARY KEY,
  casino_id VARCHAR(36),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  type VARCHAR(255) NOT NULL,
  amount VARCHAR(50),
  wagering_requirement VARCHAR(50),
  min_deposit VARCHAR(50),
  max_win VARCHAR(50),
  valid_until DATETIME,
  terms TEXT,
  code VARCHAR(50),
  is_featured BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (casino_id) REFERENCES casinos(id)
);

-- GAMES
CREATE TABLE IF NOT EXISTS games (
  id VARCHAR(36) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  provider VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL,
  rtp DECIMAL(5,2),
  volatility VARCHAR(50),
  min_bet VARCHAR(50),
  max_bet VARCHAR(50),
  supported_devices TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- REVIEWS
CREATE TABLE IF NOT EXISTS reviews (
  id VARCHAR(36) PRIMARY KEY,
  casino_id VARCHAR(36),
  bonus_id VARCHAR(36),
  game_id VARCHAR(36),
  user_name VARCHAR(255),
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  overall_rating INT NOT NULL,
  pros TEXT,
  cons TEXT,
  helpful_votes INT DEFAULT 0,
  is_verified BOOLEAN DEFAULT FALSE,
  is_published BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (casino_id) REFERENCES casinos(id),
  FOREIGN KEY (bonus_id) REFERENCES bonuses(id),
  FOREIGN KEY (game_id) REFERENCES games(id)
);
