
-- Insert test admin (username: admin, password: admin123 hashed with bcrypt)
INSERT INTO admins (id, username, password)
VALUES (
  '11111111-1111-1111-1111-111111111111',
  'admin',
  '$2b$10$QZrMNUPmAbuRfljKy3TOrODbsFJyz46U7IGt0nbZJmuhqfqHoP6y6'
);

-- Insert sample casinos
INSERT INTO casinos (id, name, description, website_url, affiliate_url, logo_url, safety_index, user_rating, established_year)
VALUES
('c1', 'Stake', 'Popular crypto casino and sportsbook.', 'https://stake.com', 'https://stake.com/?c=jGfXsQoX', 'https://getabonus.net/logos/stake.png', 8.7, 9.1, 2017),
('c2', 'BC.GAME', 'Crypto-focused platform with daily promotions.', 'https://bc.game', 'https://bc.game/i-3abbzjemx-n/', 'https://getabonus.net/logos/bcgame.png', 8.5, 8.9, 2019),
('c3', 'Roobet', 'Great games and promotions, especially in crypto space.', 'https://roobet.com', 'https://roobet.com/?ref=alkox', 'https://getabonus.net/logos/roobet.png', 8.4, 8.7, 2020);

-- Insert sample bonuses
INSERT INTO bonuses (id, casino_id, title, description, type, amount, wagering_requirement, min_deposit)
VALUES
('b1', 'c1', 'Welcome Bonus', 'Get 200% on your first deposit', 'welcome', '200%', '40x', '$20'),
('b2', 'c2', 'Free Spins', '100 free spins on registration', 'free_spins', '100 FS', '30x', 'N/A');

-- Insert sample games
INSERT INTO games (id, name, description, provider, type, rtp, volatility)
VALUES
('g1', 'Sweet Bonanza', 'High RTP slot from Pragmatic Play.', 'Pragmatic Play', 'slot', 96.51, 'high'),
('g2', 'Crazy Time', 'Live game show by Evolution Gaming.', 'Evolution', 'live', 94.41, 'medium'),
('g3', 'Book of Dead', 'Legendary slot with adventure theme.', 'Play’n GO', 'slot', 96.21, 'high');
